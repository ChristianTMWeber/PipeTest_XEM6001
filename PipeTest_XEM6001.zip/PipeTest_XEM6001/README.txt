ISE Version: Xilinx ISE 12.3
Architecture: Spartan-6
Target(s): XEM6001
